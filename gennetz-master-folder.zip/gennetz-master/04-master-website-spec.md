# GEN-NETZ master website spec

Everything here is a [Recommendation] unless marked otherwise. It merges the strong copy from the current live page with the sections the preview added.

## 1. Goals
| Goal | Measure |
|---|---|
| Visitor understands in five seconds what GEN-NETZ does | Hero tagline plus one-line description above the fold |
| Visitor trusts you with their account | Password, approval and honesty promises, real work, named testimonials |
| Visitor starts a conversation | WhatsApp and form clicks |

## 2. Audience
Brands, founders, creators and small businesses in India who want their Instagram run for them. WhatsApp is the main contact route.

## 3. Positioning
- Promise: Your Instagram. Our Responsibility.
- Proof: a repeatable system, real deliverable counts, an experienced team, a founder with a 1L+ audience.
- Honesty: no guaranteed views or followers; real data instead.
- Voice: decision 1 in 01-master-brief.md. The spec assumes agency voice ("we") with the founder as leader.

## 4. Sitemap
| Phase | Page | Purpose |
|---|---|---|
| 1 | Home (single long page with anchors) | Everything below in section 5 |
| 1 | /privacy | Privacy Policy |
| 1 | /terms | Terms of service, scope and refund policy |
| 2 | /work and /work/[client] | Case studies with numbers and reels |
| 2 | /plans | Full plan details and comparison |
| 2 | /team | Full team bios |
| 3 | /blog | Instagram tips for SEO |

## 5. Home page section order
| No. | Section | Content source |
|---|---|---|
| 1 | Header | Logo left, nav (Services, Plans, Process, Your account, Team, Work, FAQ), WhatsApp button, mobile menu |
| 2 | Hero | Logo, GEN-NETZ, NEXT GENERATION NETWORKZ, "Your Instagram, our responsibility.", one-line description, two buttons, four proof points |
| 3 | The idea | "Stop worrying about what to post. Start building a system." and the process chain |
| 4 | What we do | Four blocks from live page, expanded into six rows in the preview |
| 5 | Plans | Four cards plus comparison table, WhatsApp button per plan with pre-filled message |
| 6 | Process | Monthly workflow |
| 7 | Your account stays yours | Trust block (inverted colours) |
| 8 | Creative direction | Hook → Story → Payoff and the other three blocks |
| 9 | Team | Founder with 1L+ audience and links; editor, camera operator, content writer |
| 10 | Work | Reel row, then testimonials |
| 11 | FAQ | Six to eight questions |
| 12 | Contact | WhatsApp, email, socials, short form that opens WhatsApp pre-filled |
| 13 | Footer | Brand, links, socials, Privacy, Terms, © 2026 |
| 14 | Sticky chat button | Bottom right on all screens |

## 6. Hero spec
| Item | Value |
|---|---|
| Order | Logo, H1 GEN-NETZ, caption, tagline, description, buttons, proof points |
| Proof points | Manages your social media accounts; Never asks for your passwords; You approve before anything goes live; No surprise charges |
| Background | Light grey animated network of nodes and lines, fading to the page colour behind the text; reacts to the pointer; static when reduced motion is on |
| Logo animation | Network G draws itself once on load (about 1.3 seconds) |
| Buttons | Primary "Chat on WhatsApp" (pre-filled message); secondary "See plans" |

## 7. Copy bank
| Slot | Text |
|---|---|
| Tagline | Your Instagram, our responsibility. |
| Description | GEN-NETZ manages your social media accounts: strategy, shooting, editing, publishing and reports, all in one team. |
| Idea heading | Stop worrying about what to post. Start building a system. |
| Idea body | Your account should not depend on random ideas, inconsistent posting or chasing every trend. We build a repeatable content system around your brand, audience and goals. |
| Honesty line (positive form) | We don't guarantee views. We build the process that earns them. [Recommendation, replaces the negative headline] |
| Services heading | One team runs your whole Instagram. (preview) or Everything your Instagram needs, under one roof. (live) |
| Trust heading | Your account stays yours. |
| Contact heading | Tell us about your account |
| Meta title | GEN-NETZ | Instagram management for brands and creators in India |
| Meta description | GEN-NETZ runs your Instagram: strategy, shooting, editing, publishing and reports. Official access only. We never ask for your passwords. |

## 8. Design system (from the preview)
| Token | Light | Dark |
|---|---|---|
| Background | #E8E9EB | #0D0D0F |
| Panel | #F5F5F6 | #17171A |
| Ink (headings, buttons) | #000 | #fff |
| Text | #2B2C31 | #D9DADF |
| Muted | #5C5E66 | #9A9CA5 |
| Line | #C7C9CE | #2E2F35 |
| Accent | #2F4BFF | #8394FF |
| Inverted section background | #000 | #F1F1F3 |
| Inverted text | #F2F2F3 | #0D0D0F |

| Item | Value |
|---|---|
| Display font | Unbounded (weights 300, 500, 600, 800), fallback Arial Black, Helvetica Neue, Arial |
| Body font | Manrope (400–700), fallback Segoe UI, system-ui, Arial |
| Content width | 1120px max, 20px side gutters |
| Section spacing | 64px to 120px, fluid |
| Buttons | Pill shape, 48px minimum height, black fill, accent on hover; outline variant |
| Cards | 12px radius, hairline border; recommended plan card inverted |
| Layout style | Hairline-divided rows instead of card grids in services, team roles, FAQ |
| Motion | One hero load sequence plus a self-drawing logo; no scroll animations |
| Accessibility | Visible focus ring in accent, sr-only labels in the table, 16px form text, reduced-motion support |
| Safe areas | Header sticky below the phone status bar; content clear of bottom bar; sticky button above home indicator |
| Theme | Follows the visitor's system theme; explicit data-theme overrides supported |

## 9. Plans on the site
- Cards for Elite, Growth (Recommended, inverted), Flex, Creator, then the comparison table.
- Show "Monthly fee" for Elite, Growth, Flex and "No monthly fee" for Creator, until you decide on price ranges.
- Each plan button opens WhatsApp with a message naming the plan, as the live site does.
- Fix the Flex unit so all plans use per month.
- Text under the table: extras are quoted and confirmed before work starts.

## 10. Work and proof
- Reel tiles in a horizontal scroll row, 9:16, poster image first, video loads on tap.
- Client name, category and, where you can, one real result number.
- Testimonials with real names, roles and photos. Never invent one.
- Show only clients you have permission to show; label samples as samples.

## 11. Team
- Founder photo, title "Creator • Strategist • Content Lead", 1L+ audience, links to founder Instagram, YouTube, Facebook.
- Three role rows: professional editor, camera operator, content writer, with names and photos.
- Company socials in the footer and contact.

## 12. Technical plan
| Area | Recommendation |
|---|---|
| Build | Static site (plain HTML/CSS/JS, or Astro or Next.js if you plan a blog and case-study pages) |
| Hosting | Vercel, Netlify or Cloudflare Pages, domain gennetz.com |
| Forms | Form fills a WhatsApp message; optional email service for backup |
| Video | Compress reels (short H.264 MP4, 720p vertical), poster image, lazy load, no autoplay with sound |
| Images | WebP or AVIF, explicit width and height, alt text |
| Analytics | Privacy-friendly analytics or GA4; track WhatsApp clicks and form submits |
| SEO | Unique title and description, Open Graph and Twitter card image, sitemap.xml, robots.txt, Organization and Service structured data, fast mobile speed |
| Performance goals | Mobile Lighthouse 90+ for performance and accessibility (check after build) |
| Security | HTTPS, no client passwords ever collected, links use rel="noopener" |

## 13. Legal pages needed
- Privacy Policy: what the form and analytics collect, WhatsApp handling, contact for requests.
- Terms of service: scope of each plan, approvals, extra work quoting, ad budgets paid by the client, Meta Verified pass-through, cancellation and refunds, content ownership and portfolio permission.
- Have both reviewed by a professional. I am not a lawyer.

## 14. Assets to collect
| Asset | Status |
|---|---|
| Logo: black network G, SVG or high-resolution PNG | Needed |
| Light grey network background image (if you want the exact one, else use the animated one) | Optional |
| Founder photo | Needed |
| Team names, photos, roles | Needed |
| Years of experience number | Needed |
| Final company Instagram, Facebook, YouTube | Confirm |
| Reels (6 or more) and poster frames | Needed |
| Named testimonials, at least three | Needed |
| Case-study numbers | Needed |
| Client PDF guide | Have it, not in this folder |

## 15. Launch checklist
1. Voice decision made (01, decision 1)
2. All placeholder text removed, all links tested
3. "NEXT GENERATION NETWORKZ" spacing checked
4. Password, approval and honesty promises on the page
5. Portfolio permissions confirmed
6. Privacy and Terms live
7. Meta title, description and share image set
8. Mobile check on a small phone and a large phone; desktop check
9. Speed and accessibility check
10. WhatsApp links tested for every plan
11. Analytics events tested
12. Domain, HTTPS and redirects (www to non-www or the reverse) set

## 16. Roadmap
| Phase | Work |
|---|---|
| 1 | Update the preview with current copy, real logo, real socials, legal pages; publish the home page |
| 2 | Case-study pages, plan detail page, team page |
| 3 | Blog, lead magnet (for example a free content audit checklist), retargeting |
