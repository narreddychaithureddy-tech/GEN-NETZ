# GEN-NETZ audit and decisions

Two versions of gennetz.com were read in this chat. The page changed between them.
- Version A [Earlier live]: read first, audited in the chat, and used to build the preview. I can no longer show its raw text, so section A is rebuilt from my notes and the preview.
- Version B [Live now]: re-read on 21 Sep 2026. Word for word in 02-live-site-current-copy.md.
Limits: I read text and links only. I did not see the rendered visuals, test speed, or read outside reviews or negative-review sites.

## A. What the earlier version (A) had
| Area | Detail |
|---|---|
| Hero | Dark teal hero, line "We don't promise viral numbers" as the lead, 3D constellation emblem logo |
| Nav | Six items including a vague "Trust" |
| Plans | Agency voice ("GENNETZ"); badges on Growth read "Recommended" and "Most popular" together; Elite badge "Full production" |
| Portfolio | Six looping video tiles (Maya AI x3, GEN-NETZ Originals, Mahindra, Special events) under a "real brands" style heading |
| Testimonial | One, from an unnamed "Maya AI Launch Team", credited to a "Viral App Campaign" |
| FAQ | Five questions plus a "Updated daily • Verified Onboarding" line |
| Trust content | No password, approval, sensitive issues, no surprise charges, honest reporting |
| Footer | Footer links "Employee Handbook", "Company History", "Careers", "Support", "Meet the Team" pointing at unrelated sections; X link to generic twitter.com; one icon to "#"; city shown; © 2026 |
| Meta | Description repeated the negative hero line |

## B. Audit of the current live page (version B)

### Best parts to keep
| What | Why |
|---|---|
| "Your Instagram. Our Responsibility." as the headline | Clear, memorable, says who is in charge |
| "Stop worrying about what to post. Start building a system." | Speaks to a real pain and sells the process |
| Research → Strategy → … → Improvement chain | Shows a full system in one line |
| Four "what we do" blocks | Easy to scan |
| Four plans with real quantities | Visitors can compare |
| Plan buttons open WhatsApp with a message naming the plan | Removes friction and tells you which plan they want |
| Founder credibility (100K+ audience) and personal Instagram link | Real proof, easy to check |
| Creative direction block (Hook → Story → Payoff) | Shows craft |
| Numbered labels and consistent section labels | Clean rhythm |

### Mistakes and gaps
| No. | Problem | Fix |
|---|---|---|
| 1 | Unfinished text is public: "Replace the company placeholders with your final handles before launch" and "Instagram · Add handle", "Facebook · Add page", "YouTube · Add channel" linking to "#" | Fill in or remove before anyone sees it. Highest priority |
| 2 | Password and approval promises are gone. The key highlight you asked for is missing | Restore a "Your account stays yours" section |
| 3 | Voice clash: plans say "me" and "Chaithu personally", the rest says "we" and "team" | Pick one voice (decision 1) |
| 4 | Elite, Growth and Flex promise Chaithu edits every reel personally. It does not scale and undercuts the "team" section | Reword to "our editor" or "founder-reviewed" if that is true |
| 5 | No portfolio, no testimonials, no case studies, no client logos. The earlier version had a portfolio and one testimonial | Restore work samples and add named testimonials |
| 6 | No FAQ | Restore and extend |
| 7 | "NEXTGENERATION NETWORKZ" shows no space in the hero and footer text | Check the markup and fix |
| 8 | Meta description still says "We don't promise viral numbers" | Rewrite with a benefit and India-relevant keywords |
| 9 | "★ MOST POPULAR" on Growth is unproven | Use "Recommended" or remove |
| 10 | Team section has no people: no names, photos, or the editor, camera operator and writer you wanted | Add the team section from the preview |
| 11 | Founder Facebook link (@chaithu) is unverified | Check it opens your real profile |
| 12 | No pricing signal | Show a range or "starting from", or explain how quotes work |
| 13 | Elite and Growth look identical in volume | Make the difference obvious, for example a comparison table |
| 14 | Flex uses stories per week, others per month | Use one unit |
| 15 | Section numbering is inconsistent: "01 / Plans" repeats the "01 / STRATEGY" pattern | Number consistently or drop numbers |
| 16 | Contact is WhatsApp and email only | Add a short form that opens WhatsApp pre-filled |
| 17 | No Privacy Policy or Terms although you handle client accounts | Add both |
| 18 | "100K+" here versus "1L+" elsewhere | Use one form |

### Remove
| Item |
|---|
| The "Replace the company placeholders…" instruction sentence |
| All "Add handle / Add page / Add channel" links until real |
| "★ MOST POPULAR" until proven |
| "We don't promise viral numbers" from the meta description, and reframe the H3 on the page positively |
| First-person "me" and "Chaithu personally" if you choose agency voice |

### Add
| Item |
|---|
| "Your account stays yours" trust block (no passwords, approval, sensitive issues, no surprise charges, honest reporting) |
| Plan comparison table |
| Work section with real reels, and named testimonials |
| FAQ |
| Team section with photos and roles |
| Contact form, sticky WhatsApp button |
| Privacy Policy and Terms pages |
| Social preview image, meta description, structured data |
| Alt text on every image |

## C. Audit of the earlier version (A), for the record
Findings from the first audit, with their status on today's page.
| Finding | Status now |
|---|---|
| Hero leads with what you won't do | Reduced. Hero now leads with the tagline. The line remains as an H3 and in the meta description |
| Testimonial credit says "Viral", contradicting the honesty message | Testimonial is gone |
| Brand mismatch (GENNETZ, 3D emblem) | Header now says GEN-NETZ with logo-icon.png. Confirm it is your black G |
| No team | Founder block added. No team members yet |
| Misleading footer links (Employee Handbook, Company History…) | Gone. Footer is now plain and correct |
| Dead X link and "#" icon | Gone. Company social placeholders now use "#" |
| Growth had two badges | One badge now |
| "Nothing publishes without approval" contradicted by the exception | Statement no longer on the page |
| "Updated daily • Verified Onboarding" | Gone |
| Mahindra tile needs clearance | Tile is gone. Still needs clearance if brought back |
| Only one, unnamed, testimonial | Still no testimonials |
| No price signal | Unchanged |
| Units inconsistent (Flex stories per week) | Unchanged |
| No Privacy or Terms | Unchanged |
| Footer city | City is no longer shown |
| Only WhatsApp as contact | Unchanged (WhatsApp and email) |

## D. What the preview changed versus version A
| Change | Detail |
|---|---|
| Layout | Logo at header left; hero stack of logo, GEN-NETZ, caption, tagline |
| Look | Light grey animated network background and black logo, replacing the dark teal |
| Sections | Services rows, four plan cards plus comparison table, eight-step process, inverted "Your account stays yours" section, team, work reels with testimonial, FAQ, contact form, footer |
| Extras | WhatsApp contact form, sticky chat button, mobile menu, dark-mode tokens, reduced-motion support |
| Placeholders | Redrawn network G logo, founder photo box, team names, reel tiles instead of videos, dead Privacy and Terms links, founder social links set to "#" |
The preview was written against version A. Before the master build it should be updated with version B's copy (see 04).
