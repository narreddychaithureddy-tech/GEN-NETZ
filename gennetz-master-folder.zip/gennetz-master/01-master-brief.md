# GEN-NETZ master brief

Compiled 21 September 2026. Labels are explained in 00-README.md.

## 1. Business snapshot
| Item | Detail | Source |
|---|---|---|
| Name | GEN-NETZ (site and files also write it GENNETZ) | [You said] |
| Caption | NEXT GENERATION NETWORKZ | [You said] |
| Type | Social media / Instagram account management service | [You said] |
| Tagline | Your Instagram. Our Responsibility. | [Live now] |
| What it does | Strategy, content, shooting, editing, publishing, community and performance analysis for Instagram accounts | [Live now] |
| Strap lines | Strategy • Content • Production • Management; Strategy-led • Content-focused • Business-ready | [Live now] |
| Website | https://www.gennetz.com | [You said] |
| WhatsApp | +91 63838 84581 (https://wa.me/916383884581) | [Live now] |
| Email | hello@gennetz.com | [Live now] |
| Country | India. A city was shown in the footer of the earlier version; the current page shows none | [Earlier live] |
| Customers | Brands, founders, creators and businesses that want their Instagram run for them | [Live now] |
| Price display | Prices are replaced by "Monthly fee"; Creator stays "No monthly fee" | [You said] |
| Client PDF | A client service guide PDF exists ("GENNETZ Instagram Management Plans"). Its full text is not in this folder | [You said] |

## 2. Brand identity
| Item | Detail | Source |
|---|---|---|
| Logo | Black network-style "G" on a light grey network background | [You said] |
| Logo file on site | https://www.gennetz.com/assets/logo-icon.png | [Live now] |
| Earlier logo file | logo-3d-transparent.png, a 3D constellation emblem | [Earlier live] |
| Colour direction | Not the dark teal hero. Light grey network look with black | [You said] |
| Header | Logo at the left | [You said] |
| Hero order | Logo, then GEN-NETZ as main heading, then the caption beneath (styled like the logo image), then a tagline such as "Your Instagram, our responsibility" | [You said] |
| Spelling check | Live page text shows "NEXTGENERATION" with no space, in the hero and the footer | [Live now] |

## 3. Key messages you asked for
| Message | On current live page? |
|---|---|
| GENNETZ manages your social media accounts | Yes, in the hero body |
| GENNETZ never asks for your account passwords | No. It appeared in the earlier version and in the preview, and is missing now |
| Your Instagram, our responsibility | Yes |

## 4. Services and capabilities [Live now]
| Area | What is covered |
|---|---|
| Research & Strategy | Account audit, audience research, competitor research, positioning, content direction |
| Content Creation | Reels, posts, stories, hooks, scripts, captions, content calendars |
| Shooting & Editing | Professional camera work, creator-led shoots, cinematic edits, motion graphics, covers |
| Publishing & Analytics | Scheduling, publishing, community support, monthly reporting, ongoing improvement |
| Creative direction | Hook → Story → Payoff reels; consistent visual language; Camera → Edit → Publish; learning from the account |
| Capability chips | 100K+ creator audience experience, professional editing, camera and shooting, content writing, Instagram strategy, analytics and reporting |

## 5. Plans (source of truth) [Live now]
| | Elite | Growth | Flex | Creator |
|---|---|---|---|---|
| Badge | Full production | Most popular | Flexible | No commitment |
| Tagline | Complete Instagram Management | Collaborative Production | Lighter Pacing | Pay-As-You-Go |
| Reels | 10 / month | 10 / month | 3–4 / month | As selected |
| Posts | 4–6 / month | 4–6 / month | 1–2 / month | As selected |
| Stories | 10–12 / month | 10–12 / month | 3–4 / week | As selected |
| Shooting | Directed and shot by the team, planned visits included | Client footage + 1–2 visits / month | Client footage + 1–2 visits every 2 months | Visits available at extra charge |
| Research | Account analysis and competitor research | In-depth research and content strategy | Research and monthly content strategy | 1-on-1 strategy guidance |
| Editing | Every reel personally edited by Chaithu | Editing by Chaithu personally | Every reel personally edited by Chaithu | Editing-only packages available |
| Publishing | Planning and scheduled publishing | Publishing and scheduling | Scheduling and publishing | Not listed |
| Comments and DMs | Yes | Yes | Not listed | Not listed |
| Check-ins and reports | Weekly check-ins + monthly reports | Weekly check-in + monthly reports | Monthly performance review | Not listed |
| Meta Verified onboarding support | Yes | Yes | Yes | Not listed |
| Fee shown | Monthly fee | Monthly fee | Monthly fee | No monthly fee, per-service pricing |

Notes
- Wording on the live plans uses "me" and names Chaithu. The earlier live version and the preview used "GEN-NETZ" and "we". See decision 1 in section 13.
- Elite and Growth have identical monthly volumes. They differ only in who shoots.
- Flex counts stories per week while the others count per month.
- Rules from the earlier version, not on the current page: anything beyond a plan (extra content, full reshoot, new concept, extra visits) is quoted and confirmed first; paid ads are in no plan but can be managed for a separate fee with the ad budget paid by the client; Meta Verified subscription price changes are passed on to the client with notice.

## 6. Process versions
| Version | Steps | Where |
|---|---|---|
| Idea chain | Research → Strategy → Content → Shooting → Editing → Publishing → Community → Analytics → Improvement | [Live now] |
| Monthly workflow (4) | Plan (Research), Create (Build the content), Produce (Shoot & edit), Publish (Learn & improve) | [Live now] |
| Eight steps | Plan, Create, Produce, Edit, Review, Publish, Analyse, Improve | Preview, based on [Earlier live] |

## 7. Team and founder
| Item | Detail | Source |
|---|---|---|
| Founder title | Creator • Strategist • Content Lead | [Live now] |
| Founder credentials | First-hand creator experience, built and managed a 100K+ Instagram audience (you also say 1L+, the same figure) | [Live now], [You said] |
| Founder handle | @chaithu.z | [You said] |
| Founder platforms | Instagram, YouTube, Facebook. Meta Verified Instagram creator | [You said] |
| Founder base | Chennai, India | [You said] |
| Team roles wanted | Professional editor, camera operator ("camera control"), content writer | [You said] |
| Team names and photos | Not provided yet | [Unverified] |
| Years of experience | Not stated as a number | [Unverified] |

## 8. Social and contact links
| Account | URL | Status |
|---|---|---|
| Founder Instagram | https://www.instagram.com/chaithu.z/ | [Live now] |
| Founder YouTube | https://www.youtube.com/@chaithu.z | [Live now] |
| Founder Facebook | https://www.facebook.com/chaithu | [Live now]. [Unverified] this is your profile |
| Company Instagram | https://www.instagram.com/gen_netz | [Earlier live]. Current page shows "Add handle". [Unverified] |
| Company Facebook | https://www.facebook.com/profile.php?id=61591679835416 | [Earlier live]. Current page shows "Add page". [Unverified] |
| Company YouTube | https://www.youtube.com/@GENNETZ | [Earlier live]. Current page shows "Add channel". [Unverified] |
| WhatsApp | https://wa.me/916383884581 | [Live now] |
| Email | hello@gennetz.com | [Live now] |

## 9. Trust and policy promises [Earlier live, kept in the preview]
Not on the current page. Confirm each before publishing.
| Promise | Wording used in the preview |
|---|---|
| Access | Official, revocable access. No passwords asked. The client can remove access at any time |
| Approval | Team creates, client reviews, changes are made, client approves, then it is published. If the client sets publishing rules in advance, posting happens within them with the client's knowledge |
| Sensitive issues | Payments, refunds, personal information, legal matters and serious complaints go straight to the client. The team handles comments and general messages only |
| Charges | Extra content, reshoots, new concepts and extra visits are quoted and confirmed before work starts |
| Reporting | No guarantee of followers, views or sales. Professional work plus real performance data |

## 10. Portfolio and testimonial [Earlier live]
Not on the current page.
| Tile | Client label | Category |
|---|---|---|
| 1 | Maya AI | App promotion, SaaS and AI launch |
| 2 | Maya AI | Brand storytelling, narrative and lifestyle |
| 3 | GEN-NETZ Originals | Creative transition, motion and visual FX |
| 4 | Maya AI | Product showcase, commercial feature |
| 5 | Mahindra | Business cinematic, automotive B-roll |
| 6 | Special events | Event coverage, live culture and moments |

Testimonial used in the preview: "The exceptional execution from GEN-NETZ truly impressed us. We suggested a creative direction, and their production team delivered it with remarkable speed, strategy, and cinematic quality!" Credit: Maya AI launch team, app launch campaign.
[Unverified] The Mahindra tile needs proof it is real client work or permission, or a "sample" label.
The six clips were video files on the earlier site. Their file paths are not in this folder.

## 11. FAQ wording used in the preview [Earlier live, adapted]
| Question | Answer |
|---|---|
| Do I need to give you my Instagram password? | No. Official platform access such as Meta Business Suite or collaborator roles. Password stays with the client. Access can be removed any time |
| What if I don't like a piece of content? | Everything is approved before publishing. Reasonable changes are included. Major changes (full reshoot, new concept) are quoted first |
| Do you run paid ads? | Not in any plan. Can be managed for a separate fee. Client pays the budget. Nothing starts without approval |
| Can you guarantee followers or growth? | No. Consistent professional work, real data, monthly improvement |
| What about Meta Verified? | Support included in Elite, Growth and Flex. Meta decides eligibility and pricing. Price changes are passed on with notice |
| How do I get started? | WhatsApp or email, share account and goals, get a plan suggestion |

## 12. Design direction you asked for
| Item | Detail |
|---|---|
| Look | Professional agency site, light grey network background, black logo. Not the dark teal |
| Layout | Logo at header left; hero stack: logo, GEN-NETZ, caption, tagline |
| Highlights | Manages your social accounts; never asks for passwords |
| Team | Experienced team, founder with years of experience and 1L+ followers, editor, camera operator, content writer |
| Links | Founder's Instagram, Facebook, YouTube plus company socials |
| Preview | A final-design preview before the real build |

## 13. Decisions and open questions
| No. | Decision | Recommendation |
|---|---|---|
| 1 | Voice: personal brand ("me", "Chaithu personally edits every reel") or agency ("we", "the team") | Agency voice with the founder shown as leader. The personal-edit promise cannot scale beyond a few clients and clashes with "team" |
| 2 | Which company social accounts are final | Confirm the three handles, then remove every "Add handle" placeholder |
| 3 | Real logo file (black network G) and its light-grey network background asset | Supply SVG or high-resolution PNG |
| 4 | Founder photo, team names and photos, years of experience number | Supply before launch |
| 5 | Password and approval promises back on the page | Yes, they are a main selling point |
| 6 | Show a price range or keep "Monthly fee" | Show "starting from" or a range if you are comfortable |
| 7 | Portfolio: which clips are real client work and cleared to show | Confirm each, label samples as samples |
| 8 | Testimonials with real names and permission | Collect at least three |
| 9 | "100K+" or "1L+" | One form everywhere. "1L+" reads natively in India |
| 10 | Legal pages: Privacy Policy, Terms, scope and refund policy | Needed before launch |
| 11 | Whether to keep a "Most popular" badge | Use "Recommended" or drop it until you have client data |
