# GEN-NETZ Master Folder

Everything known about GEN-NETZ (GENNETZ), collected on 21 September 2026 so it can be used as the single source for building the master website.

## How to use this folder
Upload every file in this folder to one place Claude can read (a Claude Project's files, or a folder you point Claude Cowork / Claude Code at), then ask for the next build step, for example "build the master website from folder 04".

## Files
| File | What it holds |
|---|---|
| 00-README.md | This index |
| 01-master-brief.md | Business, brand, plans, team, contacts, promises, portfolio, FAQ, open questions |
| 02-live-site-current-copy.md | Word-for-word copy of gennetz.com as re-read on 21 Sep 2026 |
| 03-audit-and-decisions.md | Audit of the current live page, audit of the earlier version, keep / remove / add lists |
| 04-master-website-spec.md | Sitemap, section order, design system, copy bank, tech, SEO, legal, launch checklist |
| 05-conversation-log.md | Timeline of what was said and built, including what was on file before this chat |
| preview/gennetz-preview.html | The redesign preview (single file, open in any browser) |

## Labels used in every file
| Label | Meaning |
|---|---|
| [You said] | You told me this directly |
| [Live now] | Read from gennetz.com on 21 Sep 2026 |
| [Earlier live] | Seen on an earlier version of gennetz.com that the page no longer shows |
| [Recommendation] | My suggestion, not your decision |
| [Unverified] | Needs you to confirm |

## Important note
The live page I re-read today is different from the version I audited earlier in this chat. Both versions are documented so nothing is lost. See 03-audit-and-decisions.md.
